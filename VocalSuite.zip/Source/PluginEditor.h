#pragma once
#include <juce_audio_utils/juce_audio_utils.h>
#include "PluginProcessor.h"

class VocalSuiteEditor : public juce::AudioProcessorEditor, private juce::Timer
{
public:
    explicit VocalSuiteEditor(VocalSuiteAudioProcessor&);
    ~VocalSuiteEditor() override;

    void paint(juce::Graphics&) override;
    void resized() override;

private:
    void timerCallback() override;
    void addKnob(int param, const juce::String& label, const juce::String& suffix,
                 int x, int y, int decimals);
    void addGroup(const juce::String& title, int x, int y, int w);

    struct Knob
    {
        juce::Slider slider;
        juce::Label label;
        int x = 0, y = 0;
        std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> att; // destroyed first
    };

    struct Group { juce::String title; juce::Rectangle<int> area; };

    VocalSuiteAudioProcessor& proc;

    juce::ComboBox presetBox;
    juce::TextButton prevBtn { "<" }, nextBtn { ">" };

    juce::ToggleButton tuneToggle;
    juce::ComboBox keyBox, scaleBox;

    std::vector<std::unique_ptr<Knob>> knobs;
    std::vector<Group> groups;

    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> tuneAtt;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> keyAtt, scaleAtt;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(VocalSuiteEditor)
};
