#pragma once
#include <vector>
#include "Params.h"

struct PresetValue { int param; float value; };
struct Preset { const char* name; std::vector<PresetValue> v; };

// Every preset starts from the neutral defaults, then applies the values listed.
// NOTE: set the KEY and SCALE to match your song for the pitch-correction presets.
inline const std::vector<Preset>& getPresets()
{
    static const std::vector<Preset> presets =
    {
        { "Init (Neutral)", {} },

        { "Clean Pop", {
            { P_tuneOn, 1.f }, { P_scale, 1.f }, { P_retune, 90.f }, { P_tuneAmt, 60.f },
            { P_hpf, 90.f }, { P_gate, -70.f },
            { P_eqMud, -2.f }, { P_eqPres, 2.5f }, { P_eqAir, 3.f },
            { P_dsThr, -30.f }, { P_dsAmt, 0.5f },
            { P_cThr, -18.f }, { P_cRatio, 3.f }, { P_cAtt, 8.f }, { P_cRel, 100.f }, { P_cMake, 4.f },
            { P_sat, 0.1f }, { P_revMix, 0.15f }, { P_revSize, 0.45f } } },

        { "Hard Autotune", {
            { P_tuneOn, 1.f }, { P_scale, 1.f }, { P_retune, 0.f }, { P_tuneAmt, 100.f },
            { P_hpf, 100.f },
            { P_eqMud, -2.f }, { P_eqPres, 2.f }, { P_eqAir, 2.f },
            { P_dsAmt, 0.4f },
            { P_cThr, -20.f }, { P_cRatio, 4.f }, { P_cAtt, 5.f }, { P_cRel, 90.f }, { P_cMake, 5.f },
            { P_sat, 0.25f }, { P_dlyMix, 0.12f }, { P_dlyTime, 250.f },
            { P_revMix, 0.2f }, { P_revSize, 0.5f } } },

        { "Trap Tune (Minor)", {
            { P_tuneOn, 1.f }, { P_scale, 2.f }, { P_retune, 15.f }, { P_tuneAmt, 100.f },
            { P_hpf, 100.f }, { P_gate, -65.f },
            { P_eqMud, -3.f }, { P_eqPres, 3.f }, { P_eqAir, 4.f },
            { P_dsThr, -30.f }, { P_dsAmt, 0.6f },
            { P_cThr, -20.f }, { P_cRatio, 4.f }, { P_cAtt, 5.f }, { P_cRel, 80.f }, { P_cMake, 5.f },
            { P_sat, 0.2f }, { P_dlyMix, 0.2f }, { P_dlyTime, 375.f }, { P_dlyFb, 0.35f },
            { P_revMix, 0.25f }, { P_revSize, 0.6f } } },

        { "Melodic Rap Tune", {
            { P_tuneOn, 1.f }, { P_scale, 4.f }, { P_retune, 25.f }, { P_tuneAmt, 90.f },
            { P_hpf, 110.f },
            { P_eqMud, -3.f }, { P_eqPres, 3.f }, { P_eqAir, 3.f },
            { P_dsAmt, 0.6f },
            { P_cThr, -22.f }, { P_cRatio, 5.f }, { P_cAtt, 4.f }, { P_cRel, 70.f }, { P_cMake, 6.f },
            { P_sat, 0.3f }, { P_dlyMix, 0.18f }, { P_dlyTime, 300.f },
            { P_revMix, 0.2f }, { P_revSize, 0.5f } } },

        { "Radio Vocal", {
            { P_hpf, 120.f },
            { P_eqLow, -2.f }, { P_eqPres, 4.f }, { P_eqAir, 2.f },
            { P_dsThr, -30.f }, { P_dsAmt, 0.5f },
            { P_cThr, -22.f }, { P_cRatio, 5.f }, { P_cAtt, 3.f }, { P_cRel, 60.f }, { P_cMake, 6.f },
            { P_sat, 0.35f }, { P_revMix, 0.08f }, { P_revSize, 0.3f } } },

        { "Podcast Voice", {
            { P_hpf, 90.f }, { P_gate, -55.f },
            { P_eqLow, 2.f }, { P_eqMud, -2.f }, { P_eqPres, 2.f }, { P_eqAir, 1.f },
            { P_dsThr, -30.f }, { P_dsAmt, 0.5f },
            { P_cThr, -20.f }, { P_cRatio, 3.5f }, { P_cAtt, 10.f }, { P_cRel, 150.f }, { P_cMake, 6.f } } },

        { "Warm Ballad", {
            { P_tuneOn, 1.f }, { P_scale, 1.f }, { P_retune, 140.f }, { P_tuneAmt, 50.f },
            { P_hpf, 70.f },
            { P_eqLow, 2.f }, { P_eqMud, -1.f }, { P_eqPres, 1.f }, { P_eqAir, 2.5f },
            { P_dsThr, -30.f }, { P_dsAmt, 0.4f },
            { P_cThr, -16.f }, { P_cRatio, 2.5f }, { P_cAtt, 15.f }, { P_cRel, 200.f }, { P_cMake, 3.f },
            { P_sat, 0.15f }, { P_dlyMix, 0.12f }, { P_dlyTime, 450.f }, { P_dlyFb, 0.3f },
            { P_revMix, 0.3f }, { P_revSize, 0.75f } } },

        { "Airy Pop Lead", {
            { P_tuneOn, 1.f }, { P_scale, 1.f }, { P_retune, 60.f }, { P_tuneAmt, 80.f },
            { P_hpf, 110.f },
            { P_eqMud, -3.f }, { P_eqPres, 2.f }, { P_eqAir, 6.f },
            { P_dsThr, -32.f }, { P_dsAmt, 0.7f },
            { P_cThr, -20.f }, { P_cRatio, 4.f }, { P_cAtt, 6.f }, { P_cRel, 100.f }, { P_cMake, 5.f },
            { P_sat, 0.1f }, { P_dlyMix, 0.15f }, { P_dlyTime, 300.f },
            { P_revMix, 0.3f }, { P_revSize, 0.6f } } },

        { "Rap Vocal Up Front", {
            { P_hpf, 100.f }, { P_gate, -60.f },
            { P_eqMud, -3.f }, { P_eqPres, 3.f }, { P_eqAir, 2.f },
            { P_dsThr, -30.f }, { P_dsAmt, 0.6f },
            { P_cThr, -22.f }, { P_cRatio, 5.f }, { P_cAtt, 4.f }, { P_cRel, 70.f }, { P_cMake, 6.f },
            { P_sat, 0.25f }, { P_dlyMix, 0.12f }, { P_dlyTime, 250.f },
            { P_revMix, 0.08f }, { P_revSize, 0.3f } } },

        { "Backing Vocal Wide", {
            { P_tuneOn, 1.f }, { P_scale, 1.f }, { P_retune, 80.f }, { P_tuneAmt, 70.f },
            { P_hpf, 150.f },
            { P_eqMud, -3.f }, { P_eqAir, 3.f },
            { P_dsAmt, 0.6f },
            { P_cThr, -20.f }, { P_cRatio, 4.f }, { P_cAtt, 8.f }, { P_cRel, 120.f }, { P_cMake, 4.f },
            { P_dlyMix, 0.2f }, { P_dlyTime, 500.f }, { P_dlyFb, 0.4f },
            { P_revMix, 0.45f }, { P_revSize, 0.85f } } },

        { "Robot Voice", {
            { P_tuneOn, 1.f }, { P_scale, 4.f }, { P_retune, 0.f }, { P_tuneAmt, 100.f },
            { P_hpf, 120.f },
            { P_eqPres, 3.f },
            { P_cThr, -22.f }, { P_cRatio, 6.f }, { P_cAtt, 2.f }, { P_cRel, 60.f }, { P_cMake, 6.f },
            { P_sat, 0.4f }, { P_revMix, 0.1f }, { P_revSize, 0.4f } } },

        { "Lo-Fi Telephone", {
            { P_hpf, 300.f },
            { P_eqLow, -12.f }, { P_eqPres, 6.f }, { P_eqAir, -9.f },
            { P_cThr, -24.f }, { P_cRatio, 6.f }, { P_cAtt, 2.f }, { P_cRel, 80.f }, { P_cMake, 8.f },
            { P_sat, 0.6f } } },

        { "Gentle Natural Tune", {
            { P_tuneOn, 1.f }, { P_scale, 1.f }, { P_retune, 200.f }, { P_tuneAmt, 40.f },
            { P_hpf, 80.f },
            { P_eqMud, -1.5f }, { P_eqAir, 1.5f },
            { P_dsAmt, 0.4f },
            { P_cThr, -16.f }, { P_cRatio, 2.f }, { P_cAtt, 15.f }, { P_cRel, 150.f }, { P_cMake, 2.f },
            { P_revMix, 0.1f } } },

        { "Vocal Cleanup Only", {
            { P_hpf, 80.f }, { P_gate, -60.f },
            { P_eqMud, -2.f },
            { P_dsThr, -30.f }, { P_dsAmt, 0.5f },
            { P_cThr, -16.f }, { P_cRatio, 2.f }, { P_cAtt, 12.f }, { P_cRel, 140.f }, { P_cMake, 2.f } } },
    };
    return presets;
}
