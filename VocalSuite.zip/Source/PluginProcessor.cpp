#include "PluginProcessor.h"
#include "PluginEditor.h"

namespace
{
    inline float dbToLin(float db) { return std::exp(db * 0.115129255f); }

    const bool kScaleMask[5][12] =
    {
        { true, true, true, true, true, true, true, true, true, true, true, true },          // Chromatic
        { true, false, true, false, true, true, false, true, false, true, false, true },     // Major
        { true, false, true, true, false, true, false, true, true, false, true, false },     // Minor
        { true, false, true, false, true, false, false, true, false, true, false, false },   // Major Pent
        { true, false, false, true, false, true, false, true, false, false, true, false },   // Minor Pent
    };
}

//==============================================================================
VocalSuiteAudioProcessor::VocalSuiteAudioProcessor()
    : AudioProcessor(BusesProperties()
                         .withInput("Input", juce::AudioChannelSet::stereo(), true)
                         .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      apvts(*this, nullptr, "STATE", createParameterLayout())
{
    for (int i = 0; i < P_COUNT; ++i)
        raw[i] = apvts.getRawParameterValue(kParams[i].id);
}

bool VocalSuiteAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const
{
    const auto& in = layouts.getMainInputChannelSet();
    const auto& out = layouts.getMainOutputChannelSet();
    if (in != out) return false;
    return out == juce::AudioChannelSet::mono() || out == juce::AudioChannelSet::stereo();
}

void VocalSuiteAudioProcessor::prepareToPlay(double sampleRate, int)
{
    sr = sampleRate;
    detector.prepare(sr);
    for (int c = 0; c < 2; ++c)
    {
        shifter[c].prepare();
        dlyBuf[c].assign((size_t)(sr * 1.3) + 8, 0.f);
        dlyLp[c] = 0.f;
        hp1[c].reset(); hp2[c].reset(); eqLow[c].reset(); eqMud[c].reset();
        eqPres[c].reset(); eqAir[c].reset(); dsF[c].reset();
    }
    dlyW = 0;
    dlySm = (float)(0.25 * sr);

    reverb.setSampleRate(sr);
    reverb.reset();

    inSm.reset(sr, 0.03);  outSm.reset(sr, 0.03);
    inSm.setCurrentAndTargetValue(dbToLin(raw[P_inGain]->load()));
    outSm.setCurrentAndTargetValue(dbToLin(raw[P_outGain]->load()));

    detCounter = 0; unvoicedCount = 0; histCount = 0;
    desiredShift = 0.f; shiftSm = 0.f;
    bypassMix = raw[P_tuneOn]->load() > 0.5f ? 0.f : 1.f;
    gateEnv = 0.f; gateGain = 1.f; gateOpen = false;
    dsEnv = 0.f; compGr = 0.f; limGain = 1.f;

    setLatencySamples(vs::PitchShifter::kGrain / 2);
}

//==============================================================================
void VocalSuiteAudioProcessor::updatePitchTarget(int key, int scale, float amount)
{
    const float f0 = detector.detect();

    if (f0 > 0.f)
    {
        unvoicedCount = 0;
        const float midi = 69.f + 12.f * std::log2(f0 / 440.f);

        if (histCount == 0) { hist[0] = hist[1] = hist[2] = midi; histCount = 3; }
        else { hist[0] = hist[1]; hist[1] = hist[2]; hist[2] = midi; }

        // median of 3 removes single-frame octave glitches
        const float a = hist[0], b = hist[1], c = hist[2];
        const float med = std::max(std::min(a, b), std::min(std::max(a, b), c));

        const int sc = juce::jlimit(0, 4, scale);
        const int base = (int) std::floor(med + 0.5f);
        float best = 1e9f;
        int bestC = base;
        for (int n = base - 6; n <= base + 6; ++n)
        {
            const int rel = (((n - key) % 12) + 12) % 12;
            if (kScaleMask[sc][rel])
            {
                const float d = std::abs((float) n - med);
                if (d < best) { best = d; bestC = n; }
            }
        }
        desiredShift = ((float) bestC - med) * amount;
    }
    else
    {
        if (++unvoicedCount > 6)
        {
            desiredShift = 0.f;
            histCount = 0;
        }
    }
}

//==============================================================================
void VocalSuiteAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;

    const int n = buffer.getNumSamples();
    const int nCh = buffer.getNumChannels();
    for (int c = getTotalNumInputChannels(); c < nCh; ++c) buffer.clear(c, 0, n);
    if (nCh < 1 || n < 1) return;

    float* chL = buffer.getWritePointer(0);
    float* chR = nCh > 1 ? buffer.getWritePointer(1) : nullptr;
    const float fs = (float) sr;

    auto V = [this](int p) { return raw[p]->load(); };

    // ---- read parameters ----
    const bool tuneOn = V(P_tuneOn) > 0.5f;
    const int key = (int) V(P_key);
    const int scale = (int) V(P_scale);
    const float tuneAmt = V(P_tuneAmt) * 0.01f;
    const float retuneMs = V(P_retune);
    const float retuneCoeff = retuneMs < 0.5f ? 1.f : 1.f - std::exp(-1.f / (retuneMs * 0.001f * fs));
    const float bypassStep = 1.f / (0.015f * fs);

    const float hpf = V(P_hpf);
    const bool hpfOn = hpf > 22.f;
    const float gateThr = V(P_gate);
    const bool gateOnFlag = gateThr > -79.f;
    const float gateThrLin = dbToLin(gateThr);
    const float gAtk = std::exp(-1.f / (0.0005f * fs));
    const float gRelEnv = std::exp(-1.f / (0.08f * fs));
    const float gOpenCoef = std::exp(-1.f / (0.002f * fs));
    const float gCloseCoef = std::exp(-1.f / (0.15f * fs));

    const float dsAmt = V(P_dsAmt);
    const float dsThrLin = dbToLin(V(P_dsThr));
    const float dsAtk = std::exp(-1.f / (0.0005f * fs));
    const float dsRel = std::exp(-1.f / (0.04f * fs));

    const float cThr = V(P_cThr);
    const float cRatio = V(P_cRatio);
    const float cSlope = 1.f / std::max(cRatio, 1.f) - 1.f;
    const bool cOn = cRatio > 1.01f;
    const float cAtk = std::exp(-1.f / (std::max(V(P_cAtt), 0.05f) * 0.001f * fs));
    const float cRel = std::exp(-1.f / (std::max(V(P_cRel), 5.f) * 0.001f * fs));
    const float cMake = V(P_cMake);

    const float satAmt = V(P_sat);
    const float satDrive = 1.f + satAmt * 5.f;
    const float satMix = std::min(1.f, satAmt * 3.f);
    const float satNorm = 1.f / std::sqrt(satDrive);

    const float dlyMix = V(P_dlyMix);
    const float dlyFb = V(P_dlyFb);
    const float dlyTarget = V(P_dlyTime) * 0.001f * fs;
    const int dlySize = (int) dlyBuf[0].size();

    inSm.setTargetValue(dbToLin(V(P_inGain)));
    outSm.setTargetValue(dbToLin(V(P_outGain)));

    // ---- filter coefficients (once per block) ----
    for (int c = 0; c < 2; ++c)
    {
        if (hpfOn)
        {
            hp1[c].makeHighPass(sr, hpf, 0.5412);
            hp2[c].makeHighPass(sr, hpf, 1.3066);
        }
        eqLow[c].makeLowShelf(sr, 120.0, V(P_eqLow));
        eqMud[c].makePeak(sr, 300.0, 1.0, V(P_eqMud));
        eqPres[c].makePeak(sr, 3500.0, 0.8, V(P_eqPres));
        eqAir[c].makeHighShelf(sr, 10000.0, V(P_eqAir));
        dsF[c].makeHighPass(sr, 6000.0, 0.7071);
    }

    // ---- main per-sample chain ----
    for (int i = 0; i < n; ++i)
    {
        float x[2];
        x[0] = chL[i];
        x[1] = chR ? chR[i] : x[0];

        // input gain + low cut
        const float gIn = inSm.getNextValue();
        for (int c = 0; c < 2; ++c)
        {
            x[c] *= gIn;
            if (hpfOn) x[c] = hp2[c].process(hp1[c].process(x[c]));
        }

        // gate
        if (gateOnFlag)
        {
            const float lvl = std::max(std::abs(x[0]), std::abs(x[1]));
            gateEnv = lvl > gateEnv ? lvl + gAtk * (gateEnv - lvl) : lvl + gRelEnv * (gateEnv - lvl);
            if (gateEnv > gateThrLin) gateOpen = true;
            else if (gateEnv < gateThrLin * 0.6f) gateOpen = false;
            const float target = gateOpen ? 1.f : 0.03f;
            const float coef = target > gateGain ? gOpenCoef : gCloseCoef;
            gateGain = target + coef * (gateGain - target);
            x[0] *= gateGain; x[1] *= gateGain;
        }

        // pitch correction
        if (tuneOn || bypassMix < 1.f)
        {
            detector.push(0.5f * (x[0] + x[1]));
            if (++detCounter >= 256)
            {
                detCounter = 0;
                if (tuneOn) updatePitchTarget(key, scale, tuneAmt);
            }
        }
        if (!tuneOn) desiredShift = 0.f;

        shiftSm += retuneCoeff * (desiredShift - shiftSm);
        const float ratio = std::exp(shiftSm * 0.05776227f);

        if (tuneOn) bypassMix = std::max(0.f, bypassMix - bypassStep);
        else        bypassMix = std::min(1.f, bypassMix + bypassStep);

        x[0] = shifter[0].process(x[0], ratio, bypassMix);
        x[1] = shifter[1].process(x[1], ratio, bypassMix);

        // EQ
        for (int c = 0; c < 2; ++c)
        {
            x[c] = eqLow[c].process(x[c]);
            x[c] = eqMud[c].process(x[c]);
            x[c] = eqPres[c].process(x[c]);
            x[c] = eqAir[c].process(x[c]);
        }

        // de-esser (attenuates only the sibilant band)
        {
            const float sib0 = dsF[0].process(x[0]);
            const float sib1 = dsF[1].process(x[1]);
            const float lvl = std::max(std::abs(sib0), std::abs(sib1));
            dsEnv = lvl > dsEnv ? lvl + dsAtk * (dsEnv - lvl) : lvl + dsRel * (dsEnv - lvl);
            float g = dsEnv > dsThrLin ? dsThrLin / dsEnv : 1.f;
            g = 1.f - dsAmt * (1.f - g);
            x[0] -= sib0 * (1.f - g);
            x[1] -= sib1 * (1.f - g);
        }

        // compressor (stereo linked, soft knee)
        {
            float target = 0.f;
            if (cOn)
            {
                const float lvl = std::max(std::abs(x[0]), std::abs(x[1]));
                const float lvlDb = 20.f * std::log10(std::max(lvl, 1e-6f));
                const float over = lvlDb - cThr;
                const float knee = 6.f;
                if (2.f * over < -knee) target = 0.f;
                else if (2.f * std::abs(over) <= knee)
                {
                    const float t = over + knee * 0.5f;
                    target = cSlope * t * t / (2.f * knee);
                }
                else target = cSlope * over;
            }
            const float coef = target < compGr ? cAtk : cRel;
            compGr = target + coef * (compGr - target);
            const float g = std::exp((compGr + cMake) * 0.115129255f);
            x[0] *= g; x[1] *= g;
        }

        // saturation
        if (satAmt > 0.001f)
        {
            for (int c = 0; c < 2; ++c)
            {
                const float wet = std::tanh(x[c] * satDrive) * satNorm;
                x[c] += satMix * (wet - x[c]);
            }
        }

        // delay (darkened feedback)
        {
            dlySm += 0.0008f * (dlyTarget - dlySm);
            for (int c = 0; c < 2; ++c)
            {
                const float d = dlySm + (c == 1 ? 0.007f * fs : 0.f);
                float rp = (float) dlyW - d;
                while (rp < 0.f) rp += (float) dlySize;
                const int idx = (int) rp;
                const float fr = rp - (float) idx;
                const float del = dlyBuf[c][(size_t)(idx % dlySize)] * (1.f - fr)
                                + dlyBuf[c][(size_t)((idx + 1) % dlySize)] * fr;
                dlyLp[c] += 0.35f * (del - dlyLp[c]);
                dlyBuf[c][(size_t) dlyW] = x[c] + dlyFb * dlyLp[c];
                x[c] += dlyMix * dlyLp[c];
            }
            dlyW = (dlyW + 1) % dlySize;
        }

        chL[i] = x[0];
        if (chR) chR[i] = x[1];
    }

    // ---- reverb ----
    const float revMix = V(P_revMix);
    if (revMix > 0.001f)
    {
        juce::Reverb::Parameters rp;
        rp.roomSize = V(P_revSize);
        rp.damping = 0.5f;
        rp.wetLevel = revMix * 0.25f;
        rp.dryLevel = 0.5f;
        rp.width = 1.0f;
        rp.freezeMode = 0.f;
        reverb.setParameters(rp);
        if (chR) reverb.processStereo(chL, chR, n);
        else     reverb.processMono(chL, n);
    }

    // ---- output gain + limiter ----
    const float ceiling = dbToLin(-0.3f);
    const float limAtk = std::exp(-1.f / (0.0002f * fs));
    const float limRel = std::exp(-1.f / (0.06f * fs));
    for (int i = 0; i < n; ++i)
    {
        const float g = outSm.getNextValue();
        float l = chL[i] * g;
        float r = chR ? chR[i] * g : l;

        const float peak = std::max(std::abs(l), std::abs(r));
        const float target = peak > ceiling ? ceiling / peak : 1.f;
        const float coef = target < limGain ? limAtk : limRel;
        limGain = target + coef * (limGain - target);

        l = juce::jlimit(-ceiling, ceiling, l * limGain);
        r = juce::jlimit(-ceiling, ceiling, r * limGain);
        chL[i] = l;
        if (chR) chR[i] = r;
    }
}

//==============================================================================
void VocalSuiteAudioProcessor::applyPreset(int index)
{
    const auto& presets = getPresets();
    if (index < 0 || index >= (int) presets.size()) return;
    currentPreset = index;

    for (int i = 0; i < P_COUNT; ++i)
        if (auto* p = apvts.getParameter(kParams[i].id))
            p->setValueNotifyingHost(p->getDefaultValue());

    for (const auto& pv : presets[(size_t) index].v)
        if (auto* p = apvts.getParameter(kParams[pv.param].id))
            p->setValueNotifyingHost(p->convertTo0to1(pv.value));
}

void VocalSuiteAudioProcessor::getStateInformation(juce::MemoryBlock& destData)
{
    auto state = apvts.copyState();
    state.setProperty("preset", currentPreset, nullptr);
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    if (xml != nullptr) copyXmlToBinary(*xml, destData);
}

void VocalSuiteAudioProcessor::setStateInformation(const void* data, int sizeInBytes)
{
    std::unique_ptr<juce::XmlElement> xml(getXmlFromBinary(data, sizeInBytes));
    if (xml != nullptr && xml->hasTagName(apvts.state.getType()))
    {
        auto vt = juce::ValueTree::fromXml(*xml);
        currentPreset = (int) vt.getProperty("preset", 0);
        apvts.replaceState(vt);
    }
}

juce::AudioProcessorEditor* VocalSuiteAudioProcessor::createEditor()
{
    return new VocalSuiteEditor(*this);
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new VocalSuiteAudioProcessor();
}
