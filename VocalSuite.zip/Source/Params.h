#pragma once
#include <juce_audio_processors/juce_audio_processors.h>

// Index of every parameter. Order MUST match kParams below.
enum P
{
    P_inGain, P_tuneOn, P_key, P_scale, P_retune, P_tuneAmt,
    P_hpf, P_gate,
    P_eqLow, P_eqMud, P_eqPres, P_eqAir,
    P_dsThr, P_dsAmt,
    P_cThr, P_cRatio, P_cAtt, P_cRel, P_cMake,
    P_sat,
    P_dlyMix, P_dlyTime, P_dlyFb,
    P_revMix, P_revSize,
    P_outGain,
    P_COUNT
};

struct ParamSpec
{
    const char* id;
    const char* name;
    int type;      // 0 = float, 1 = choice, 2 = bool
    float mn, mx, def, skew;
};

inline const ParamSpec kParams[P_COUNT] =
{
    { "in_gain",  "Input Gain",      0, -12.f,  12.f,   0.f,  1.f },
    { "tune_on",  "Pitch Correct",   2,   0.f,   1.f,   0.f,  1.f },
    { "key",      "Key",             1,   0.f,  11.f,   0.f,  1.f },
    { "scale",    "Scale",           1,   0.f,   4.f,   1.f,  1.f },
    { "retune",   "Retune Speed",    0,   0.f, 400.f,  40.f,  0.5f },
    { "tune_amt", "Tune Amount",     0,   0.f, 100.f, 100.f,  1.f },

    { "hpf",      "Low Cut",         0,  20.f, 300.f,  20.f,  0.5f },
    { "gate",     "Gate",            0, -80.f, -20.f, -80.f,  1.f },

    { "eq_low",   "Low Shelf",       0, -12.f,  12.f,   0.f,  1.f },
    { "eq_mud",   "Mud Cut",         0, -12.f,  12.f,   0.f,  1.f },
    { "eq_pres",  "Presence",        0, -12.f,  12.f,   0.f,  1.f },
    { "eq_air",   "Air",             0, -12.f,  12.f,   0.f,  1.f },

    { "ds_thr",   "De-Ess Thresh",   0, -50.f, -10.f, -30.f,  1.f },
    { "ds_amt",   "De-Ess Amount",   0,   0.f,   1.f,   0.f,  1.f },

    { "c_thr",    "Comp Thresh",     0, -40.f,   0.f,   0.f,  1.f },
    { "c_ratio",  "Comp Ratio",      0,   1.f,  20.f,   1.f,  0.5f },
    { "c_att",    "Comp Attack",     0,   0.1f,100.f,  10.f,  0.4f },
    { "c_rel",    "Comp Release",    0,  20.f,1000.f, 120.f,  0.5f },
    { "c_make",   "Makeup Gain",     0,   0.f,  18.f,   0.f,  1.f },

    { "sat",      "Saturation",      0,   0.f,   1.f,   0.f,  1.f },

    { "dly_mix",  "Delay Mix",       0,   0.f,   1.f,   0.f,  1.f },
    { "dly_time", "Delay Time",      0,  50.f,1000.f, 250.f,  0.6f },
    { "dly_fb",   "Delay Feedback",  0,   0.f,   0.8f,  0.3f, 1.f },

    { "rev_mix",  "Reverb Mix",      0,   0.f,   1.f,   0.f,  1.f },
    { "rev_size", "Reverb Size",     0,   0.f,   1.f,   0.5f, 1.f },

    { "out_gain", "Output Gain",     0, -12.f,  12.f,   0.f,  1.f },
};

inline juce::StringArray getKeyNames()
{
    return { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" };
}

inline juce::StringArray getScaleNames()
{
    return { "Chromatic", "Major", "Minor", "Major Pent", "Minor Pent" };
}

inline juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout()
{
    juce::AudioProcessorValueTreeState::ParameterLayout layout;

    for (int i = 0; i < P_COUNT; ++i)
    {
        const ParamSpec& s = kParams[i];

        if (s.type == 0)
        {
            layout.add(std::make_unique<juce::AudioParameterFloat>(
                juce::ParameterID{ s.id, 1 }, s.name,
                juce::NormalisableRange<float>(s.mn, s.mx, 0.01f, s.skew), s.def));
        }
        else if (s.type == 1)
        {
            layout.add(std::make_unique<juce::AudioParameterChoice>(
                juce::ParameterID{ s.id, 1 }, s.name,
                i == P_key ? getKeyNames() : getScaleNames(), (int) s.def));
        }
        else
        {
            layout.add(std::make_unique<juce::AudioParameterBool>(
                juce::ParameterID{ s.id, 1 }, s.name, s.def > 0.5f));
        }
    }
    return layout;
}
