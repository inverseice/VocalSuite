#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include "Params.h"
#include "Presets.h"
#include "DSP.h"

class VocalSuiteAudioProcessor : public juce::AudioProcessor
{
public:
    VocalSuiteAudioProcessor();
    ~VocalSuiteAudioProcessor() override = default;

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported(const BusesLayout& layouts) const override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "Vocal Suite"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    double getTailLengthSeconds() const override { return 2.0; }

    // Presets are exposed as host "programs" so FL Studio's preset menu works too
    int getNumPrograms() override { return (int) getPresets().size(); }
    int getCurrentProgram() override { return currentPreset; }
    void setCurrentProgram(int index) override { if (index != currentPreset) applyPreset(index); }
    const juce::String getProgramName(int index) override
    {
        const auto& p = getPresets();
        return (index >= 0 && index < (int) p.size()) ? juce::String(p[(size_t) index].name) : juce::String();
    }
    void changeProgramName(int, const juce::String&) override {}

    void getStateInformation(juce::MemoryBlock& destData) override;
    void setStateInformation(const void* data, int sizeInBytes) override;

    void applyPreset(int index);

    juce::AudioProcessorValueTreeState apvts;

private:
    void updatePitchTarget(int key, int scale, float amount);

    std::atomic<float>* raw[P_COUNT] {};
    double sr = 44100.0;
    int currentPreset = 0;

    juce::SmoothedValue<float, juce::ValueSmoothingTypes::Linear> inSm, outSm;

    vs::Biquad hp1[2], hp2[2], eqLow[2], eqMud[2], eqPres[2], eqAir[2], dsF[2];

    vs::PitchDetector detector;
    vs::PitchShifter shifter[2];
    int detCounter = 0, unvoicedCount = 0, histCount = 0;
    float hist[3] { 0.f, 0.f, 0.f };
    float desiredShift = 0.f, shiftSm = 0.f, bypassMix = 1.f;

    float gateEnv = 0.f, gateGain = 1.f;
    bool gateOpen = false;
    float dsEnv = 0.f;
    float compGr = 0.f;
    float limGain = 1.f;

    std::vector<float> dlyBuf[2];
    int dlyW = 0;
    float dlySm = 11025.f;
    float dlyLp[2] { 0.f, 0.f };

    juce::Reverb reverb;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(VocalSuiteAudioProcessor)
};
