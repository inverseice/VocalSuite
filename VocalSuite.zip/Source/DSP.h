#pragma once
#include <vector>
#include <cmath>
#include <algorithm>

namespace vs
{
constexpr double kPi = 3.14159265358979323846;

//==============================================================================
// RBJ-cookbook biquad filter
struct Biquad
{
    float b0 = 1.f, b1 = 0.f, b2 = 0.f, a1 = 0.f, a2 = 0.f, z1 = 0.f, z2 = 0.f;

    void reset() { z1 = z2 = 0.f; }

    inline float process(float x) noexcept
    {
        const float y = b0 * x + z1;
        z1 = b1 * x - a1 * y + z2;
        z2 = b2 * x - a2 * y;
        return y;
    }

    void setRaw(double B0, double B1, double B2, double A0, double A1, double A2)
    {
        b0 = (float)(B0 / A0); b1 = (float)(B1 / A0); b2 = (float)(B2 / A0);
        a1 = (float)(A1 / A0); a2 = (float)(A2 / A0);
    }

    static double clampF(double fs, double f) { return std::min(std::max(f, 10.0), fs * 0.45); }

    void makeHighPass(double fs, double f, double q)
    {
        f = clampF(fs, f);
        const double w = 2.0 * kPi * f / fs, c = std::cos(w), s = std::sin(w), al = s / (2.0 * q);
        setRaw((1 + c) / 2, -(1 + c), (1 + c) / 2, 1 + al, -2 * c, 1 - al);
    }

    void makePeak(double fs, double f, double q, double gainDb)
    {
        f = clampF(fs, f);
        const double A = std::pow(10.0, gainDb / 40.0);
        const double w = 2.0 * kPi * f / fs, c = std::cos(w), s = std::sin(w), al = s / (2.0 * q);
        setRaw(1 + al * A, -2 * c, 1 - al * A, 1 + al / A, -2 * c, 1 - al / A);
    }

    void makeLowShelf(double fs, double f, double gainDb)
    {
        f = clampF(fs, f);
        const double A = std::pow(10.0, gainDb / 40.0);
        const double w = 2.0 * kPi * f / fs, c = std::cos(w), s = std::sin(w);
        const double al = s / 2.0 * std::sqrt(2.0);
        const double sq = 2.0 * std::sqrt(A) * al;
        setRaw(A * ((A + 1) - (A - 1) * c + sq),
               2 * A * ((A - 1) - (A + 1) * c),
               A * ((A + 1) - (A - 1) * c - sq),
               (A + 1) + (A - 1) * c + sq,
               -2 * ((A - 1) + (A + 1) * c),
               (A + 1) + (A - 1) * c - sq);
    }

    void makeHighShelf(double fs, double f, double gainDb)
    {
        f = clampF(fs, f);
        const double A = std::pow(10.0, gainDb / 40.0);
        const double w = 2.0 * kPi * f / fs, c = std::cos(w), s = std::sin(w);
        const double al = s / 2.0 * std::sqrt(2.0);
        const double sq = 2.0 * std::sqrt(A) * al;
        setRaw(A * ((A + 1) + (A - 1) * c + sq),
               -2 * A * ((A - 1) + (A + 1) * c),
               A * ((A + 1) + (A - 1) * c - sq),
               (A + 1) - (A - 1) * c + sq,
               2 * ((A - 1) - (A + 1) * c),
               (A + 1) - (A - 1) * c - sq);
    }
};

//==============================================================================
// YIN-style pitch detector (runs on a 2x decimated signal to save CPU)
class PitchDetector
{
public:
    void prepare(double sampleRate)
    {
        dsFs = sampleRate * 0.5;
        tauMin = std::max(8, (int)(dsFs / 1000.0));   // ~1000 Hz max
        tauMax = std::min((int)(dsFs / 70.0), 2000);  // ~70 Hz min
        window = std::max(512, tauMax);
        need = window + tauMax + 2;
        ring.assign(kRing, 0.f);
        temp.assign((size_t) need, 0.f);
        dn.assign((size_t)(tauMax + 2), 0.f);
        wr = 0; filled = 0; acc = 0.f; phase = 0;
    }

    void push(float s)
    {
        acc += s;
        if (++phase >= 2)
        {
            ring[(size_t) wr] = acc * 0.5f;
            wr = (wr + 1) & (kRing - 1);
            acc = 0.f; phase = 0;
            if (filled < need) ++filled;
        }
    }

    // returns fundamental frequency in Hz, or 0 if unvoiced / too quiet
    float detect()
    {
        if (filled < need) return 0.f;

        const int start = wr - need;
        for (int i = 0; i < need; ++i)
            temp[(size_t) i] = ring[(size_t)((start + i) & (kRing - 1))];

        double e = 0.0;
        for (int i = need - window; i < need; ++i) e += (double) temp[(size_t) i] * temp[(size_t) i];
        if (std::sqrt(e / window) < 0.003) return 0.f;

        const float* x = temp.data();
        const int b = tauMax;
        double run = 0.0;
        dn[0] = 1.f;
        for (int tau = 1; tau <= tauMax; ++tau)
        {
            double d = 0.0;
            for (int j = 0; j < window; ++j)
            {
                const float df = x[b + j] - x[b + j - tau];
                d += (double)(df * df);
            }
            run += d;
            dn[(size_t) tau] = run > 1e-12 ? (float)(d * tau / run) : 1.f;
        }

        int best = -1;
        for (int tau = tauMin; tau < tauMax; ++tau)
        {
            if (dn[(size_t) tau] < 0.15f)
            {
                while (tau + 1 < tauMax && dn[(size_t)(tau + 1)] < dn[(size_t) tau]) ++tau;
                best = tau;
                break;
            }
        }

        if (best < 0)
        {
            float mn = 1e9f;
            for (int tau = tauMin; tau < tauMax; ++tau)
                if (dn[(size_t) tau] < mn) { mn = dn[(size_t) tau]; best = tau; }
            if (best < 0 || mn > 0.35f) return 0.f;
        }

        float t = (float) best;
        if (best > 1 && best < tauMax - 1)
        {
            const float s0 = dn[(size_t)(best - 1)], s1 = dn[(size_t) best], s2 = dn[(size_t)(best + 1)];
            const float denom = s0 + s2 - 2.f * s1;
            if (std::abs(denom) > 1e-9f) t = (float) best + 0.5f * (s0 - s2) / denom;
        }
        if (t < 1.f) return 0.f;
        return (float)(dsFs / (double) t);
    }

private:
    static constexpr int kRing = 8192;
    std::vector<float> ring, temp, dn;
    double dsFs = 22050.0;
    int tauMin = 22, tauMax = 315, window = 512, need = 900;
    int wr = 0, filled = 0, phase = 0;
    float acc = 0.f;
};

//==============================================================================
// Two-tap crossfading delay-line pitch shifter
class PitchShifter
{
public:
    static constexpr int kGrain = 1024;

    PitchShifter() : buf((size_t) kSize, 0.f) {}

    void prepare()
    {
        std::fill(buf.begin(), buf.end(), 0.f);
        w = 0; ph = 0.5f;
    }

    // ratio > 1 shifts up. bypassMix: 1 = clean (delayed) dry, 0 = fully shifted
    float process(float in, float ratio, float bypassMix)
    {
        buf[(size_t) w] = in;
        w = (w + 1) & kMask;

        const float dry = tap((float) kGrain * 0.5f);
        if (bypassMix >= 1.f) { ph = 0.5f; return dry; }

        float p2 = ph + 0.5f;
        if (p2 >= 1.f) p2 -= 1.f;

        const float tp = 6.2831853f;
        const float g1 = 0.5f - 0.5f * std::cos(tp * ph);
        const float g2 = 0.5f - 0.5f * std::cos(tp * p2);
        const float wet = g1 * tap(ph * (float) kGrain) + g2 * tap(p2 * (float) kGrain);

        ph += (1.f - ratio) / (float) kGrain;
        ph -= std::floor(ph);

        return wet + bypassMix * (dry - wet);
    }

private:
    static constexpr int kSize = 4096, kMask = kSize - 1;
    std::vector<float> buf;
    int w = 0;
    float ph = 0.5f;

    float tap(float d) const
    {
        d = std::max(d, 2.f);
        float rp = (float) w - d;
        if (rp < 0.f) rp += (float) kSize;
        const int i = (int) rp;
        const float f = rp - (float) i;
        return buf[(size_t)(i & kMask)] * (1.f - f) + buf[(size_t)((i + 1) & kMask)] * f;
    }
};

} // namespace vs
