#include "PluginEditor.h"

namespace
{
    const juce::Colour kBg      (0xff12141a);
    const juce::Colour kPanel   (0xff1d212b);
    const juce::Colour kAccent  (0xff4fd1c5);
    const juce::Colour kText    (0xffd6dae3);
}

VocalSuiteEditor::VocalSuiteEditor(VocalSuiteAudioProcessor& p)
    : juce::AudioProcessorEditor(&p), proc(p)
{
    setSize(890, 520);

    // ---- preset bar ----
    const auto& presets = getPresets();
    for (size_t i = 0; i < presets.size(); ++i)
        presetBox.addItem(presets[i].name, (int) i + 1);
    presetBox.setSelectedItemIndex(proc.getCurrentProgram(), juce::dontSendNotification);
    presetBox.onChange = [this] { proc.applyPreset(presetBox.getSelectedItemIndex()); };
    addAndMakeVisible(presetBox);

    prevBtn.onClick = [this]
    {
        const int cnt = (int) getPresets().size();
        presetBox.setSelectedItemIndex((presetBox.getSelectedItemIndex() + cnt - 1) % cnt);
    };
    nextBtn.onClick = [this]
    {
        const int cnt = (int) getPresets().size();
        presetBox.setSelectedItemIndex((presetBox.getSelectedItemIndex() + 1) % cnt);
    };
    addAndMakeVisible(prevBtn);
    addAndMakeVisible(nextBtn);

    // ---- pitch block ----
    tuneToggle.setButtonText("Pitch Correction");
    tuneToggle.setColour(juce::ToggleButton::textColourId, kText);
    tuneToggle.setColour(juce::ToggleButton::tickColourId, kAccent);
    addAndMakeVisible(tuneToggle);

    keyBox.addItemList(getKeyNames(), 1);
    scaleBox.addItemList(getScaleNames(), 1);
    addAndMakeVisible(keyBox);
    addAndMakeVisible(scaleBox);

    tuneAtt  = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(proc.apvts, kParams[P_tuneOn].id, tuneToggle);
    keyAtt   = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(proc.apvts, kParams[P_key].id, keyBox);
    scaleAtt = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(proc.apvts, kParams[P_scale].id, scaleBox);

    // ---- layout constants ----
    const int r0 = 64, r1 = 214, r2 = 364;
    const int ky = 26; // knob offset below group top

    // Row 0
    addGroup("PITCH", 10, r0, 360);
    addKnob(P_retune,  "Retune Speed", " ms", 180, r0 + ky, 0);
    addKnob(P_tuneAmt, "Amount",       " %",  270, r0 + ky, 0);

    addGroup("CLEANUP", 380, r0, 290);
    addKnob(P_inGain, "Input",   " dB", 390, r0 + ky, 1);
    addKnob(P_hpf,    "Low Cut", " Hz", 480, r0 + ky, 0);
    addKnob(P_gate,   "Gate",    " dB", 570, r0 + ky, 0);

    addGroup("DE-ESSER", 680, r0, 200);
    addKnob(P_dsThr, "Threshold", " dB", 690, r0 + ky, 0);
    addKnob(P_dsAmt, "Amount",    "",    780, r0 + ky, 2);

    // Row 1
    addGroup("EQ", 10, r1, 380);
    addKnob(P_eqLow,  "Low",      " dB", 20,  r1 + ky, 1);
    addKnob(P_eqMud,  "Mud Cut",  " dB", 110, r1 + ky, 1);
    addKnob(P_eqPres, "Presence", " dB", 200, r1 + ky, 1);
    addKnob(P_eqAir,  "Air",      " dB", 290, r1 + ky, 1);

    addGroup("SATURATION", 400, r1, 110);
    addKnob(P_sat, "Drive", "", 410, r1 + ky, 2);

    addGroup("DELAY", 520, r1, 290);
    addKnob(P_dlyMix,  "Mix",      "",    530, r1 + ky, 2);
    addKnob(P_dlyTime, "Time",     " ms", 620, r1 + ky, 0);
    addKnob(P_dlyFb,   "Feedback", "",    710, r1 + ky, 2);

    // Row 2
    addGroup("COMPRESSOR", 10, r2, 470);
    addKnob(P_cThr,   "Threshold", " dB", 20,  r2 + ky, 1);
    addKnob(P_cRatio, "Ratio",     ":1",  110, r2 + ky, 1);
    addKnob(P_cAtt,   "Attack",    " ms", 200, r2 + ky, 1);
    addKnob(P_cRel,   "Release",   " ms", 290, r2 + ky, 0);
    addKnob(P_cMake,  "Makeup",    " dB", 380, r2 + ky, 1);

    addGroup("REVERB", 490, r2, 200);
    addKnob(P_revMix,  "Mix",  "", 500, r2 + ky, 2);
    addKnob(P_revSize, "Size", "", 590, r2 + ky, 2);

    addGroup("OUTPUT", 700, r2, 110);
    addKnob(P_outGain, "Level", " dB", 710, r2 + ky, 1);

    startTimerHz(4);
    resized();
}

VocalSuiteEditor::~VocalSuiteEditor()
{
    stopTimer();
}

void VocalSuiteEditor::addGroup(const juce::String& title, int x, int y, int w)
{
    groups.push_back({ title, juce::Rectangle<int>(x, y, w, 140) });
}

void VocalSuiteEditor::addKnob(int param, const juce::String& label, const juce::String& suffix,
                               int x, int y, int decimals)
{
    auto k = std::make_unique<Knob>();
    k->x = x; k->y = y;

    k->slider.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
    k->slider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 80, 16);
    k->slider.setColour(juce::Slider::rotarySliderFillColourId, kAccent);
    k->slider.setColour(juce::Slider::rotarySliderOutlineColourId, juce::Colour(0xff343a48));
    k->slider.setColour(juce::Slider::thumbColourId, juce::Colours::white);
    k->slider.setColour(juce::Slider::textBoxTextColourId, kText);
    k->slider.setColour(juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
    addAndMakeVisible(k->slider);

    k->label.setText(label, juce::dontSendNotification);
    k->label.setJustificationType(juce::Justification::centred);
    k->label.setColour(juce::Label::textColourId, juce::Colour(0xff9aa3b5));
    k->label.setFont(juce::Font(12.0f));
    addAndMakeVisible(k->label);

    k->att = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(
        proc.apvts, kParams[param].id, k->slider);

    // nicer value text with units (set after the attachment so it is not overwritten)
    k->slider.textFromValueFunction = [suffix, decimals](double v)
    {
        return juce::String(v, decimals) + suffix;
    };
    k->slider.valueFromTextFunction = [](const juce::String& t) { return t.getDoubleValue(); };
    k->slider.updateText();

    knobs.push_back(std::move(k));
}

void VocalSuiteEditor::paint(juce::Graphics& g)
{
    g.fillAll(kBg);

    g.setColour(kAccent);
    g.setFont(24.0f);
    g.drawText("VOCAL SUITE", 20, 10, 300, 36, juce::Justification::centredLeft);

    for (const auto& grp : groups)
    {
        g.setColour(kPanel);
        g.fillRoundedRectangle(grp.area.toFloat(), 8.0f);
        g.setColour(kAccent.withAlpha(0.85f));
        g.setFont(12.0f);
        g.drawText(grp.title, grp.area.getX() + 12, grp.area.getY() + 5, 200, 18,
                   juce::Justification::centredLeft);
    }
}

void VocalSuiteEditor::resized()
{
    prevBtn.setBounds(340, 14, 32, 30);
    presetBox.setBounds(378, 14, 280, 30);
    nextBtn.setBounds(664, 14, 32, 30);

    const int r0 = 64;
    tuneToggle.setBounds(22, r0 + 30, 150, 26);
    keyBox.setBounds(22, r0 + 66, 60, 26);
    scaleBox.setBounds(88, r0 + 66, 84, 26);

    for (auto& k : knobs)
    {
        k->label.setBounds(k->x, k->y, 90, 16);
        k->slider.setBounds(k->x, k->y + 16, 90, 98);
    }
}

void VocalSuiteEditor::timerCallback()
{
    const int cur = proc.getCurrentProgram();
    if (presetBox.getSelectedItemIndex() != cur)
        presetBox.setSelectedItemIndex(cur, juce::dontSendNotification);
}
